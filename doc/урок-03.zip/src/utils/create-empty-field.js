import { PLAYER } from '../constants';

export const createEmptyField = () => new Array(9).fill(PLAYER.NOBODY);
