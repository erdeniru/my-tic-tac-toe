import { STATUS } from './status';

export const PLAYER_ACTION = {
	[STATUS.TURN]: 'Ходит',
	[STATUS.WIN]: 'Победил',
};
