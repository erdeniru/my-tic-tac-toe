export const STATUS = {
	TURN: 0,
	WIN: 1,
	DRAW: 2,
};
