import { PLAYER } from './player';

export const PLAYER_NAME = {
	[PLAYER.CROSS]: 'крестик',
	[PLAYER.NOUGHT]: 'нолик',
};
