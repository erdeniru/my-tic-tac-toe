export const PLAYER = {
	CROSS: 0,
	NOUGHT: 1,
	NOBODY: 2,
};
