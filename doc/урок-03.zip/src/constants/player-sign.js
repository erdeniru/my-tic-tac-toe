import { PLAYER } from './player';

export const PLAYER_SIGN = {
	[PLAYER.CROSS]: '╳',
	[PLAYER.NOUGHT]: '◯',
	[PLAYER.NOBODY]: '',
};
